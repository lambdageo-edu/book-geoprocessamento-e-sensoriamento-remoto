﻿--SCRIPT DO EXERCICIO LAGO AZUL
create extension postgis;
-- Lagos
CREATE TABLE lagos (
id INTEGER NOT NULL PRIMARY KEY,
nome CHARACTER VARYING(64),
geom geometry(POLYGON,29193));

-- Estradas
CREATE TABLE estradas (
id INTEGER NOT NULL PRIMARY KEY,
nome CHARACTER VARYING(64),
apelido CHARACTER VARYING(64),
num_pistas INTEGER,
geom geometry(LINESTRING,29193));

-- Estradas Duplicadas
CREATE TABLE estradas_duplicadas (
id INTEGER NOT NULL PRIMARY KEY,
nome CHARACTER VARYING(64),
num_pistas INTEGER,
geom geometry(MULTILINESTRING,29193));

-- Florestas
CREATE TABLE florestas (
id INTEGER NOT NULL PRIMARY KEY,
nome CHARACTER VARYING(64),
geom geometry(MULTIPOLYGON,29193));

-- Pontes
CREATE TABLE pontes (
id INTEGER NOT NULL PRIMARY KEY,
nome CHARACTER VARYING(64),
geom geometry(POINT,29193));

-- Rios
CREATE TABLE rios (
id INTEGER NOT NULL PRIMARY KEY,
nome CHARACTER VARYING(64),
geom geometry(LINESTRING,29193));

-- Edificações
CREATE TABLE edificacoes (
id INTEGER NOT NULL PRIMARY KEY,
endereco CHARACTER VARYING(64),
geom_pt geometry(POINT,29193),
geom_pol geometry(POLYGON,29193));

-- Viveiros
CREATE TABLE viveiros (
id INTEGER NOT NULL PRIMARY KEY,
nome CHARACTER VARYING(64),
tipo CHARACTER VARYING(64),
geom geometry(MULTIPOLYGON,29193));

-- Localidades
CREATE TABLE localidades (
id INTEGER NOT NULL PRIMARY KEY,
nome CHARACTER VARYING(64),
geom geometry(POLYGON,29193));

-- Limites do Mapa
CREATE TABLE bordas_mapa (
id INTEGER NOT NULL PRIMARY KEY,
geom geometry(POLYGON,29193));


-- INSERCAO DOS DADOS
-- Lagos
INSERT INTO lagos VALUES (
101, 'LAGO AZUL',
ST_PolyFromText(
'POLYGON(
(52 18,66 23,73 9,48 6,52 18),
(59 18,67 18,67 13,59 13,59 18)
)',
29193));

-- Estradas
INSERT INTO estradas VALUES(102, 'BR 500', NULL, 2,
ST_LineFromText(
'LINESTRING( 0 18, 10 21, 16 23, 28 26, 44 31 )' ,29193));
INSERT INTO estradas VALUES(103, 'BR 500', 'Rua Central', 4,
ST_LineFromText(
'LINESTRING( 44 31, 56 34, 70 38 )' ,29193));
INSERT INTO estradas VALUES(104, 'BR 500', NULL, 2,
ST_LineFromText(
'LINESTRING( 70 38, 72 48 )' ,29193));
INSERT INTO estradas VALUES(105, 'Rua Central', NULL, 4,
ST_LineFromText(
'LINESTRING( 70 38, 84 42 )' ,29193));
INSERT INTO estradas VALUES(106, 'Estrada Local', NULL,
1,
ST_LineFromText(
'LINESTRING( 28 26, 28 0 )',29193));

-- Estradas Duplicadas
INSERT INTO estradas_duplicadas VALUES(119, 'BR 700', 4,
ST_MLineFromText(
'MULTILINESTRING((10 48,10 21,10 0),
(16 0,16 23,16 48))', 29193));

-- Florestas
INSERT INTO florestas VALUES(109, 'Floresta Verde',
ST_MPolyFromText(
'MULTIPOLYGON(((28 26,28 0,84 0,84 42,28 26),
(52 18,66 23,73 9,48 6,52 18)),((59 18,67 18,67 13,59 13,59 18)))',
29193));
INSERT INTO florestas VALUES(121, 'Floresta Estadual',
ST_MPolyFromText(
'MULTIPOLYGON(((28 26,28 0,84 0,84 42,28 26)))',29193));

-- Pontes
INSERT INTO pontes VALUES(110, 'Ponte Uniao', ST_PointFromText(
'POINT( 44 31 )', 29193));

-- Rios
INSERT INTO rios VALUES(111, 'Rio Limpo',
ST_LineFromText(
'LINESTRING( 38 48, 44 41, 41 36, 44 31, 52 18 )', 29193));
INSERT INTO rios VALUES(112, NULL,
ST_LineFromText(
'LINESTRING( 76 0, 78 4, 73 9 )', 29193));

-- Edificacoes
INSERT INTO edificacoes VALUES(113, 'Rua Central, 123',
ST_PointFromText(
'POINT( 52 30 )', 29193),
ST_PolyFromText(
'POLYGON( ( 50 31, 54 31, 54 29, 50 29, 50 31) )', 29193));
INSERT INTO edificacoes VALUES(114, 'Rua Central, 215',
ST_PointFromText(
'POINT( 64 33 )', 29193),
ST_PolyFromText(
'POLYGON( ( 66 34, 62 34, 62 32, 66 32, 66 34) )', 29193));

-- Viveiros
INSERT INTO viveiros VALUES(120, NULL, 'Viveiros Adultos',
ST_MPolyFromText(
'MULTIPOLYGON( ( ( 24 44, 22 42, 24 40, 24 44) ),
( ( 26 44, 26 40, 28 42, 26 44) ) )', 29193));

-- Localidades
INSERT INTO localidades VALUES(117, 'Ashton',
ST_PolyFromText(
'POLYGON( ( 62 48, 84 48, 84 30, 56 30, 56 34, 62 48) )', 29193));
INSERT INTO localidades VALUES(118, 'Ilha do Ganso',
ST_PolyFromText(
'POLYGON( ( 67 13, 67 18, 59 18, 59 13, 67 13) )', 29193));

-- Bordas do Mapa
INSERT INTO bordas_mapa VALUES(115,
ST_PolyFromText(
'POLYGON( ( 0 0, 0 48, 84 48, 84 0, 0 0 ) )', 29193));



